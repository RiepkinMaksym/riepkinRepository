import java.io.IOException;

public class Tester extends Student {

	public static void main(String[] args)  throws IOException {
		// TODO Auto-generated method stub
		Student t=new Student();
		t.addStudent();
		t.addStudent();
		t.addStudent();
		t.addStudent();
		t.bestGrade();
		t.worstGrade();
//		for(int i=0;i<t.Students.length;i++){
//			Student k=(Student) t.Students[i];
//			System.out.println(k.adress);
//			System.out.println(k.StudentName);
//		}
	}

}
