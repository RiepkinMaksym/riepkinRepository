import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.InputMismatchException;
import java.util.Scanner;

public class EnterInfo  {
	public Object[] enterInfo(Object[] Students, String StudName, float grade, String adress) throws IOException {
		Scanner sc = new Scanner(System.in);
		Scanner bt = new Scanner(System.in);
		// BufferedReader br= new BufferedReader(new
		// InputStreamReader(System.in));

		System.out.println("Enter name ");
		Student t = (Student) Students[Students.length - 1];
		StudName = sc.nextLine();
		System.out.println("Enter average grade ");
		int flag = 0;
		try {
			grade = bt.nextFloat();
		} catch (InputMismatchException e) {
			System.out.println("You should enter number");
			flag = 1;
			bt.reset();
		}
		if (flag == 0) {
			// bt.reset();
			// bt.close();
			// sc.reset();
			System.out.println("Enter adress ");
			adress = sc.nextLine();
			// sc.close();
			t.adress = adress;
			t.averageGradeOfStudent = grade;
			t.StudentName = StudName;
			return Students;
		}
		else{
			return null;
		}
	}
}
