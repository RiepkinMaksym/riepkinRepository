
public class Group {
	Object[] Students;
}
