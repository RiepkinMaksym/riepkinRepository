import java.io.IOException;
import java.util.Arrays;

public class Student extends Group {
	String StudentName;
	float averageGradeOfStudent;
	String adress;

	public void addStudent() throws IOException {
		EnterInfo ei = new EnterInfo();
		Object dynamicStud = new Student();
		expand(dynamicStud);
		Students = ei.enterInfo(Students, StudentName, averageGradeOfStudent, adress);

	}

	public float[] sort(float[] dynamicGrade) {

		for (int j = 1; j < dynamicGrade.length; j++) {

			for (int k = 0; k < dynamicGrade.length - 1; k++) {

				if (dynamicGrade[k] > dynamicGrade[k + 1]) {
					float hold = 0;
					hold = dynamicGrade[k];
					dynamicGrade[k] = dynamicGrade[k + 1];
					dynamicGrade[k + 1] = hold;

				}
			}
		}
		return dynamicGrade;
	}

	public void bestGrade() {
		float[] dynamicGrade = new float[Students.length];
		for (int i = 0; i < Students.length; i++) {
			Student st = (Student) Students[i];
			dynamicGrade[i] = st.averageGradeOfStudent;

		}
		dynamicGrade = sort(dynamicGrade);
		System.out.println("The best grade is " + dynamicGrade[dynamicGrade.length - 1]);
	}

	public void worstGrade() {
		float[] dynamicGrade = new float[Students.length];
		for (int i = 0; i < Students.length; i++) {
			Student st = (Student) Students[i];
			dynamicGrade[i] = st.averageGradeOfStudent;

		}
		dynamicGrade = sort(dynamicGrade);

		System.out.println("The best grade is " + dynamicGrade[0]);
	}

	@Override
	public String toString() {
		return "Student [Students=" + Arrays.toString(Students) + "]";
	}

	public void expand(Object whatToAdd) {
		if (Students != null) {
			Object dynamicFaculty[] = new Object[Students.length + 1];
			for (int i = 0; i < Students.length; i++) {
				dynamicFaculty[i] = Students[i];
			}
			dynamicFaculty[Students.length] = whatToAdd;
			Students = dynamicFaculty;
		} else {
			Object dynamicFaculty[] = new Object[1];
			dynamicFaculty[0] = whatToAdd;
			Students = dynamicFaculty;
		}
	}

	public String getStudentName() {
		return StudentName;
	}

	public void setStudentName(String studentName) {
		StudentName = studentName;
	}

	public float getAverageGradeOfStudent() {
		return averageGradeOfStudent;
	}

	public void setAverageGradeOfStudent(float averageGradeOfStudent) {
		this.averageGradeOfStudent = averageGradeOfStudent;
	}

	public String getAdress() {
		return adress;
	}

	public void setAdress(String adress) {
		this.adress = adress;
	}

}
