import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeMap;
import java.util.TreeSet;

class Student{
	public String GroupName;
	public String StudentName;
	public Student(String groupName, String studentName) {
		GroupName = groupName;
		StudentName = studentName;
	}
	
}

public class Tester {
	ArrayList Students=new ArrayList();
	
	
	public Student asking(){
		System.out.println("Enter Group Name");
		Scanner sc=new Scanner(System.in);
		String groupName=sc.nextLine();
		
		System.out.println("Enter Student Name");
		String studentName=sc.nextLine();
		Student st=new Student(groupName,studentName);
		return st;
	}
	
	
	public void addStudent(){
		
		Students.add(asking());
		System.out.println(Students.toString());
	}
	
	
	public void deleteStudent(){
		Student st=asking();
		for(int i=0;i<Students.size();i++){
			Student st1=(Student) Students.get(i);
			
			if(st.GroupName.matches(st1.GroupName)&&st.StudentName.matches(st1.StudentName)){
				Students.remove(i);
			}
		}
	}
	
	public void editStudent(){
		Student st=asking();
		for(int i=0;i<Students.size();i++){
			Student st1=(Student) Students.get(i);
			
			if(st.GroupName.matches(st1.GroupName)&&st.StudentName.matches(st1.StudentName)){
				st=asking();
				st1.GroupName=st.GroupName;
				st1.StudentName=st.StudentName;
			}
		}
	}
	
	public static void main(String[] args) {
		Tester t=new Tester();
		t.addStudent();
		t.deleteStudent();
		t.editStudent();
	}
	
	
	
	
}
