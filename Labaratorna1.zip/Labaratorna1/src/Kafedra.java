import java.util.Arrays;
import java.util.Scanner;

public class Kafedra extends Faculty {
	String whichFaculty;
	String nameOfKafedra;
	public Object[] Kafedras;

	public String getWhichFaculty() {
		return whichFaculty;
	}

	public void setWhichFaculty(String whichFaculty) {
		this.whichFaculty = whichFaculty;
	}

	public String getNameOfKafedra() {
		return nameOfKafedra;
	}

	public void setNameOfKafedra(String nameOfKafedra) {
		this.nameOfKafedra = nameOfKafedra;
	}

	protected void addKafedra() {
		WorkingWithArrays a = new WorkingWithArrays();
		System.out.println("Input faculty to which kafedra is related");
		String facultyName = sc.nextLine();
		if (a.lookingForFaculty(Faculties, facultyName) != null) {
			System.out.println("Input name of kafedra, you want to add");
			String kafedraName = sc.nextLine();
			if (a.lookingForKafedra(Kafedras, facultyName, kafedraName) == null) {
				Object dynamicKafedra = new Kafedra();
				Kafedras = a.expand(Kafedras, dynamicKafedra);
				Kafedra k = (Kafedra) Kafedras[Kafedras.length - 1];
				k.setWhichFaculty(facultyName);
				k.setNameOfKafedra(kafedraName);
				System.out.println(kafedraName + " kafedra has been added");
			} else {
				System.out.println("Error,there is such kafedra in selected faculty");
			}
		} else {
			System.out.println("Error,no such faculty");
		}
	}

	protected void editKafedra() {
		WorkingWithArrays a = new WorkingWithArrays();
		System.out.println("Input faculty to which kafedra is related");
		String facultyName = sc.nextLine();

		if (a.lookingForFaculty(Faculties, facultyName) != null) {
			System.out.println("Input name of kafedra, you want to edit");
			String kafedraName = sc.nextLine();
			if (a.lookingForKafedra(Kafedras, facultyName, kafedraName) != null) {
				for (int j = 0; j < Kafedras.length; j++) {
					Kafedra k1 = (Kafedra) Kafedras[j];
					if (k1.whichFaculty.matches(facultyName) && k1.nameOfKafedra.matches(kafedraName)) {
						System.out.println("Enter new name of kafedra");
						k1.setNameOfKafedra(sc.nextLine());
						break;
					}
				}
				System.out.println("The name of " + kafedraName + " has been changed");
			}
		} else {
			System.out.println("There are no such kafedras in selected faculty");
		}

	}

	protected void deleteKadedra() {
		WorkingWithArrays a = new WorkingWithArrays();
		System.out.println("Input faculty name to which kadedra is related");
		String facultyName = sc.nextLine();

		if (a.lookingForFaculty(Faculties, facultyName) != null) {
			System.out.println("Input name of kafedra, you want to delete");
			String kafedraName = sc.nextLine();
			if (a.lookingForKafedra(Kafedras, facultyName, kafedraName) != null) {
				for (int j = 0; j < Kafedras.length; j++) {
					Kafedra k1 = (Kafedra) Kafedras[j];
					if (k1.whichFaculty.matches(facultyName) && k1.nameOfKafedra.matches(kafedraName)) {
						Kafedras = a.deleteIndex(Kafedras, j);
						break;

					}
				}
				System.out.println("Operation is successful");
			} else {
				System.out.println("There are no such kafedras in selected faculty");
			}
		} else {
			System.out.println("There are no such kafedras in selected faculty");
		}
		System.out.println(Kafedras.length);
	}

	@Override
	public String toString() {
		return "Kafedra [Kafedras=" + Arrays.toString(Kafedras) + "]";
	}

}
