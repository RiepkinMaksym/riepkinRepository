import java.io.IOException;

public class Tester {
	public static void main(String[] args) throws IOException {
		WorkingWithArrays w=new WorkingWithArrays();
		w.menu();
	}
}
