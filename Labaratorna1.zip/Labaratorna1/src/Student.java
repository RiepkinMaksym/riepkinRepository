import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Student extends Teacher {
	int course;
	Object[] Students;
	String Kafedra;
	String Faculty;
	String Name;
	Scanner sc = new Scanner(System.in);

	protected void addStudent() throws IOException {
		WorkingWithArrays a = new WorkingWithArrays();
		System.out.println("Input faculty to which you want to add student");

		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		String facultyName = reader.readLine();
		if (a.lookingForFaculty(Faculties, facultyName) != null) {
			System.out.println("Input kafedra name");
			String kafedraName = sc.nextLine();

			if (a.lookingForKafedra(Kafedras, facultyName, kafedraName) != null) {
				System.out.println("Input name of the student");
				String name = sc.nextLine();
				System.out.println("Input cource");
				Scanner bb = new Scanner(System.in);
				int cource = 0;
				int flag = 0;
				try {
					cource = bb.nextInt();
				} catch (InputMismatchException e) {
					System.out.println("You should enter number");
					flag = 1;
					bb.reset();
				}
				if (flag == 0) {

					if (a.lookingForStudent(Students, facultyName, kafedraName, name, cource) == null) {
						Object dynamic = new Student();
						Students = a.expand(Students, dynamic);
						Student k = (Student) Students[Students.length - 1];
						k.setFaculty(facultyName);
						k.setKafedra(kafedraName);
						k.setName(name);
						k.setCourse(cource);
					} else {
						System.out.println("There is such student");
					}
				}
			} else {
				System.out.println("No such Kafedra");
			}
		} else {
			System.out.println("There are no such faculty");
		}

	}

	protected void editStudent() {
		WorkingWithArrays a = new WorkingWithArrays();
		System.out.println("Input faculty to which you want to edit student");
		String facultyName = sc.nextLine();
		if (a.lookingForFaculty(Faculties, facultyName) != null) {
			System.out.println("Input name of kafedra");
			String kafedraName = sc.nextLine();
			if (a.lookingForKafedra(Kafedras, facultyName, kafedraName) != null) {
				System.out.println("Input name of student");
				String studentName = sc.nextLine();
				System.out.println("Input cource of the student");
				Scanner bb = new Scanner(System.in);
				int cource = 0;
				int flag = 0;
				try {
					cource = bb.nextInt();
				} catch (InputMismatchException e) {
					System.out.println("You should enter number");
					flag = 1;
					bb.reset();
				}
				if (flag == 0) {
					if (a.lookingForStudent(Students, facultyName, kafedraName, studentName, cource) != null) {
						for (int i = 0; i < Students.length; i++) {
							Student t = (Student) Students[i];
							if (t.Name.matches(studentName) && t.Faculty.matches(facultyName)
									&& t.Kafedra.matches(kafedraName) && t.course == cource) {
								System.out.println("Enter new faculty name");
								facultyName = sc.nextLine();
								System.out.println("Enter new kafedra name");
								kafedraName = sc.nextLine();
								System.out.println("Enter new student name");
								studentName = sc.nextLine();
								System.out.println("Enter new student cource");
								cource = bb.nextInt();
								bb.reset();
								if (a.lookingForStudent(Students, facultyName, kafedraName, studentName,
										cource) == null) {
									t.setFaculty(facultyName);
									t.setKafedra(kafedraName);
									t.setName(studentName);
									t.setCourse(cource);
									System.out.println("Successful");
									break;
								} else {
									System.out.println("Error");
								}
							}
						}
					} else {
						System.out.println("There is such student");
					}

				}
			} else {
				System.out.println("There are no such kafedras in selected faculty");
			}
		} else {
			System.out.println("There are no such faculty");
		}

	}

	protected void deleteStudent() {
		WorkingWithArrays a = new WorkingWithArrays();
		System.out.println("Input faculty to which you want to add student");
		String facultyName = sc.nextLine();
		if (a.lookingForFaculty(Faculties, facultyName) != null) {
			System.out.println("Input name of kafedra");
			String kafedraName = sc.nextLine();
			if (a.lookingForKafedra(Kafedras, facultyName, kafedraName) != null) {
				System.out.println("Input name of student");
				String studentName = sc.nextLine();
				System.out.println("Input cource of the student");
				Scanner bb = new Scanner(System.in);
				int flag = 0;
				int cource = 0;
				try {
					cource = bb.nextInt();
				} catch (InputMismatchException e) {
					System.out.println("You should enter number");
					flag = 1;
					bb.reset();
				}
				if (flag == 0) {
					if (a.lookingForStudent(Students, facultyName, kafedraName, studentName, cource) != null) {
						for (int i = 0; i < Students.length; i++) {
							Student t = (Student) Students[i];
							if (t.Faculty.matches(facultyName) && t.Kafedra.matches(kafedraName)
									&& t.Name.matches(studentName) && t.course == cource) {
								Students = a.deleteIndex(Students, i);
								System.out.println("Student " + studentName + " deleted");
							}
						}
					}
				} else {
					System.out.println("There no such student");
				}
			} else {
				System.out.println("There are no such kafedras in selected faculty");
			}

		} else {
			System.out.println("There are no such faculty");
		}
	}

	
	protected void sortStudentsByKafedra(){
		if(Students!=null){
			WorkingWithArrays a = new WorkingWithArrays();
		String[] dynamic = new String[Students.length];
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter kafedra from which you want to sort students");
		String kafedraName = sc.nextLine();
		int index = 0;
		for (int i = 0; i < Students.length; i++) {
			Student s = (Student) Students[i];
			if (s.Kafedra.matches(kafedraName)) {
				dynamic[index] = s.Name;
				index++;
			}
		}
		
		a.sortByAlphabet(index, dynamic);
		}
		
	}
	
	protected void sortStudentsOfKafedraByCourse(){
if(Students!=null){
			System.out.println("Enter name of kafedra");
		String kafedraName=sc.nextLine();
		Object[] dynamicStud=new Object[Students.length];
		int index=0;
		for(int i=0;i<Students.length;i++){
			Student s=(Student) Students[i];
			if(s.Kafedra.matches(kafedraName)){
				dynamicStud[i]=s;
				index++;
			}
		}
		for (int i = dynamicStud.length - 1; i > 0; i--) {
			for (int j = 0; j < i; j++) {
				Student s = (Student) dynamicStud[j];
				Student s1 = (Student) dynamicStud[j + 1];
				int cource = s.getCourse();
				int cource1 = s1.getCourse();
				if (cource > cource1) {
					int tmp = cource;
					s.setCourse(cource1);
					s1.setCourse(tmp);
				}
			}
		}
			for (int i = 0; i < dynamicStud.length; i++) {
				Student s = (Student) dynamicStud[i];

				System.out.println(s.getName() + " " + s.getCourse() + " cource");
			}
		}
		
	}
	
	
	protected void sortStudentsOfKafedraCourse(){
		
if(Students!=null){
			WorkingWithArrays a = new WorkingWithArrays();
			System.out.println("Enter kafedra");
			String kafedraName = sc.nextLine();
			Scanner bb = new Scanner(System.in);
			String[] dynamic = new String[Students.length];
			System.out.println("If you want to print all students of that kafedra type 0 if sort by alphabet type >0");
			int cource = 0;
			int which = bb.nextInt();
			bb.reset();
			int flag = 0;
			int index = 0;
			System.out.println("Enter course");
			try {
				cource = bb.nextInt();
			} catch (InputMismatchException e) {
				System.out.println("You should enter number");
				flag = 1;
				bb.reset();
			}
			if (flag == 0) {
				for (int i = 0; i < Students.length; i++) {
					Student s = (Student) Students[i];
					if (s.Kafedra.matches(kafedraName) && s.course == cource) {
						if (which == 0) {
							System.out.println(
									"Student of " + s.Faculty + " " + s.Kafedra + " is on " + s.course + " year");
						} else {
							dynamic[i] = s.Name;
							index++;
						}
					}
				}
				if (which != 0) {
					a.sortByAlphabet(index, dynamic);
				}
			}
		}
	
	}
	
	
	protected void lookForStudentWithParams(){
if(Students!=null){
			System.out.println("1 by name");
		System.out.println("2 by course");
		System.out.println("3 by kafedra");
		Scanner input=new Scanner(System.in);
		int value=0;
		try {
			value = input.nextInt();
		} catch (InputMismatchException e) {
			System.out.println("You should enter number");
			
			input.reset();
		}
		if(value==1){
			System.out.println("Enter name");
			String name=sc.nextLine();
			for(int i=0;i<Students.length;i++){
				Student s=(Student) Students[i];
				if(s.Name.matches(name)){
					System.out.println("Student of "+s.Faculty+" "+s.Kafedra+" is on "+s.course+" year");
				}
			}
		}
		else if(value==2){
			System.out.println("Enter course");
			int course=0;
			try {
				course = input.nextInt();
			} catch (InputMismatchException e) {
				System.out.println("You should enter number");
				
				input.reset();
			}
			for(int i=0;i<Students.length;i++){
				Student s=(Student) Students[i];
				if(s.course==course){
					System.out.println("Student of "+s.Faculty+" "+s.Kafedra+" is on "+s.course+" year");
				}
			}
		}
		else if(value==3){
			System.out.println("Enter kafedra name");
			String name=sc.nextLine();
			for(int i=0;i<Students.length;i++){
				Student s=(Student) Students[i];
				if(s.Kafedra.matches(name)){
					System.out.println("Student of "+s.Faculty+" "+s.Kafedra+" is on "+s.course+" year");
				}
			}
		}
		}
		
	}
	
 	protected void sortStudentsByAlphabet(){
if(Students!=null){
			WorkingWithArrays a = new WorkingWithArrays();
		String[] dynamic = new String[Students.length];
		int index=Students.length;
		for(int i=0;i<index;i++){
			Student s=(Student) Students[i];
			dynamic[i]=s.Name;
		}
		a.sortByAlphabet(index, dynamic);
		}
		
	}
	
	
	protected void sortStudentsOfTheFacultyByAlphabet() {
if(Students!=null){
			WorkingWithArrays a = new WorkingWithArrays();
		String[] dynamic = new String[Students.length];
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter faculty from which you want to sort students");
		String facultyName = sc.nextLine();
		int index = 0;
		for (int i = 0; i < Students.length; i++) {
			Student s = (Student) Students[i];
			if (s.Faculty.matches(facultyName)) {
				dynamic[index] = s.Name;
				index++;
			}
		}
		
		a.sortByAlphabet(index, dynamic);
		}
		
	}

	protected void sortByCourse() {
if(Students!=null){
			Object[] dynamicStud = Students;
			for (int i = dynamicStud.length - 1; i > 0; i--) {
				for (int j = 0; j < i; j++) {
					Student s = (Student) dynamicStud[j];
					Student s1 = (Student) dynamicStud[j + 1];
					int cource = s.getCourse();
					int cource1 = s1.getCourse();
					if (cource > cource1) {
						int tmp = cource;
						s.setCourse(cource1);
						s1.setCourse(tmp);
					}
				}
			}
			for (int i = 0; i < dynamicStud.length; i++) {
				Student s = (Student) dynamicStud[i];

				System.out.println(s.getName() + " " + s.getCourse() + " cource");
			}
		}
		
	}

	public String getKafedra() {
		return Kafedra;
	}

	public void setKafedra(String kafedra) {
		Kafedra = kafedra;
	}

	public String getFaculty() {
		return Faculty;
	}

	public void setFaculty(String faculty) {
		Faculty = faculty;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public int getCourse() {
		return course;
	}

	public void setCourse(int cource) {
		this.course = cource;
	}

}
