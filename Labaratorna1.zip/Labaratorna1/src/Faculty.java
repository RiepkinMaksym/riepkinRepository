import java.util.Arrays;
import java.util.Scanner;

public class Faculty extends Mohila {
	public Object[] Faculties;
	Scanner sc = new Scanner(System.in);
	String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Faculty(String name) {
		this.name = name;
	}

	public Faculty() {
	}

	protected void addFaculty() {
		WorkingWithArrays a = new WorkingWithArrays();
		System.out.println("Type faculty name which you want to add");
		String facultyName = sc.nextLine();
		if (a.lookingForFaculty(Faculties, facultyName) == null) {
			Object dynamicFaculty = new Faculty(facultyName);
			Faculties = a.expand(Faculties, dynamicFaculty);
			System.out.println(facultyName + " faculty has been added");
		} else {
			System.out.println("There is such faculty");
		}
	}

	protected void deleteFaculty() {
		WorkingWithArrays a = new WorkingWithArrays();
		System.out.println("Input which faculty you want to delete");
		String facultyName = sc.nextLine();
		if (a.lookingForFaculty(Faculties, facultyName) != null) {
			for (int i = 0; i < Faculties.length; i++) {
				Faculty f = (Faculty) Faculties[i];
				if (f.name.equalsIgnoreCase(facultyName)) {
					Faculties[i] = null;
					Faculties = a.deleteIndex(Faculties, i);
					break;
				}
			}
			System.out.println("Operation is done");
		} else {
			System.out.println("There is no such faculty");
		}
	}

	@Override
	public String toString() {
		return "faculty=" + Arrays.toString(Faculties) + "]";
	}

	protected void editFaculty() {
		WorkingWithArrays a = new WorkingWithArrays();
		System.out.println("Type the faculty you want to edit");
		String facultyName = sc.nextLine();
		if (a.lookingForFaculty(Faculties, facultyName) != null) {
			System.out.println("Type new name of " + facultyName + " faculty");
			String newName = sc.nextLine();
			if (a.lookingForFaculty(Faculties, newName) == null) {
				for (int i = 0; i < Faculties.length; i++) {
					Faculty f = (Faculty) Faculties[i];
					if (f.name.equalsIgnoreCase(facultyName)) {
						f.setName(newName);
					}
				}
			}
			else{
				System.out.println("There is such faculty");
			}
		}
		else{
			System.out.println("There is no such faculty");
		}
	}
}
