import java.io.IOException;
import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.Scanner;

public class WorkingWithArrays extends Student {
	Scanner sc = new Scanner(System.in);

	public Object[] deleteIndex(Object[] array, int index) {
		WorkingWithArrays w = new WorkingWithArrays();
		Object dynamicArray[] = new Object[array.length - 1];
		for (int i = 0; i < array.length - 1; i++) {
			if (i != index) {
				dynamicArray[i] = array[i];
			}
		}

		return dynamicArray;

	}

	public Object[] expand(Object[] nameToExpand, Object whatToAdd) {
		if (nameToExpand != null) {
			Object dynamicFaculty[] = new Object[nameToExpand.length + 1];
			for (int i = 0; i < nameToExpand.length; i++) {
				dynamicFaculty[i] = nameToExpand[i];
			}
			dynamicFaculty[nameToExpand.length] = whatToAdd;
			nameToExpand = dynamicFaculty;
		} else {
			Object dynamicFaculty[] = new Object[1];
			dynamicFaculty[0] = whatToAdd;
			nameToExpand = dynamicFaculty;
		}
		return nameToExpand;
	}

	protected Object lookingForFaculty(Object[] Faculties, String whatLookingFor) {
		if (Faculties != null) {
			for (int i = 0; i < Faculties.length; i++) {
				Faculty f = (Faculty) Faculties[i];
				if (f.name.equalsIgnoreCase(whatLookingFor)) {
					return f;
				}
			}
			return null;
		}
		return null;
	}

	protected Object lookingForKafedra(Object[] Kafedras, String facultyName, String KafedraName) {

		if (Kafedras != null) {
			for (int i = 0; i < Kafedras.length; i++) {
				Kafedra k = (Kafedra) Kafedras[i];
				if (k.whichFaculty.matches(facultyName) && k.nameOfKafedra.matches(KafedraName)) {
					return k;
				}
			}

		}
		return null;
	}

	protected Object lookingForTeacher(Object[] Teachers, String facultyName, String kafedraName, String name) {
		if (Teachers != null) {
			for (int i = 0; i < Teachers.length; i++) {
				Teacher t = (Teacher) Teachers[i];
				if (t.Faculty.matches(facultyName) && t.Kafedra.matches(kafedraName) && t.Name.matches(name)) {
					return t;
				}
			}
		}
		return null;
	}

	protected Object lookingForStudent(Object[] Students, String facultyName, String kafedraName, String name,
			int cource) {
		if (Students != null) {
			for (int i = 0; i < Students.length; i++) {
				Student t = (Student) Students[i];
				if (t.Faculty.matches(facultyName) && t.Kafedra.matches(kafedraName) && t.Name.matches(name)
						&& t.course == cource) {
					return t;
				}
			}

		}
		return null;
	}

	protected void sortByAlphabet(int index, String[] dynamic) {
		for (int i = index - 1; i > 0; i--) {
			for (int j = 0; j < i; j++) {
				String s = dynamic[j];
				String s1 = dynamic[j + 1];
				if (s.compareTo(s1) > 0) {
					String tmp = s;
					s = s1;
					s1 = tmp;
					dynamic[j] = s;
					dynamic[j + 1] = s1;
				}
			}
		}
		for (int i = 0; i < index; i++) {
			System.out.println(dynamic[i]);
		}
	}

	protected void menu() throws IOException {
		Scanner pp = new Scanner(System.in);
		while (true) {
			System.out.println("1 - Створити/видалити/редагувати факультет");
			System.out.println("2 - Створити/видалити/редагувати кафедру факультета");
			System.out.println("3 - Додати/видалити/редагувати студентa до кафедри.");
			System.out.println("4 - Додати/видалити/редагувати викладача до кафедри.");
			System.out.println("5 - Знайти студента за ПІБ, курсом або групою.");
			System.out.println("6 - Знайти викладача за ПІБ, курсом або групою.");
			System.out.println("7 - Сортировки");
			System.out.println("8 - Вихід");
			int value = 0;
			try {
				value = pp.nextInt();
			} catch (InputMismatchException e) {
				System.out.println("Wrong");
				continue;
			}
			if (value == 1) {
				System.out.println("1 - Створити факультет");
				System.out.println("2 - Видалити факультет");
				System.out.println("3 - Редагувати факультет");
				System.out.println("else - Вихід");
				try {
					value = pp.nextInt();
				} catch (InputMismatchException e) {
					System.out.println("Wrong");
					continue;
				}
				if (value == 1) {
					addFaculty();
				} else if (value == 2) {
					deleteFaculty();
				} else if (value == 3) {
					editFaculty();
				}
				value = -1;

			} else if (value == 2) {
				System.out.println("1 - Створити кафедру");
				System.out.println("2 - Видалити кафедру");
				System.out.println("3 - Редагувати кафедру");
				System.out.println("else - Вихід");
				try {
					value = pp.nextInt();
				} catch (InputMismatchException e) {
					System.out.println("Wrong");
					continue;
				}
				if (value == 1) {
					addKafedra();
				} else if (value == 2) {
					deleteKadedra();
				} else if (value == 3) {
					editKafedra();
				}
				value = -1;
			} else if (value == 3) {
				System.out.println("1 - Додати студента");
				System.out.println("2 - Видалити студента");
				System.out.println("3 - Редагувати студента");
				System.out.println("else - Вихід");
				try {
					value = pp.nextInt();
				} catch (InputMismatchException e) {
					System.out.println("Wrong");
					continue;
				}
				if (value == 1) {
					addStudent();
				} else if (value == 2) {
					deleteStudent();
				} else if (value == 3) {
					editStudent();
				}
				value = -1;

			} else if (value == 4) {
				System.out.println("1 - Додати студента");
				System.out.println("2 - Видалити студента");
				System.out.println("3 - Редагувати студента");
				System.out.println("else - Вихід");
				try {
					value = pp.nextInt();
				} catch (InputMismatchException e) {
					System.out.println("Wrong");
					continue;
				}
				if (value == 1) {
					addTeacher();
				} else if (value == 2) {
					deleteTeacher();
				} else if (value == 3) {
					editTeacher();
				}
				value = -1;

			} else if (value == 5) {
				lookForStudentWithParams();
			} else if (value == 6) {
				lookingForTeacherWithParams();
			} else if (value == 7) {
				System.out.println("1 - Вивести всіх студентів впорядкованих за курсами");
				System.out.println("2 - Вивести всіх студентів впорядкованих за aлфавітом");
				System.out.println("3 - Вивести всіх викладачів впорядкованих за алфавітом");
				System.out.println("4 - Вивести всіх студентів кафедри впорядкованих за курсами");
				System.out.println("5 - Вивести всіх студентів кафедри впорядкованих за алфавітом");
				System.out.println("6 - Вивести всіх викладачів кафедри впорядкованих за алфавітом");
				System.out.println("7 - Всі студенти кафедри за курсом");
				System.out.println("else - вихід");

				try {
					value = pp.nextInt();
				} catch (InputMismatchException e) {
					System.out.println("Wrong");
					continue;
				}

				if (value == 1) {
					sortByCourse();
				} else if (value == 2) {
					sortStudentsByAlphabet();
				} else if (value == 3) {
					sortTeachersByAlphabet();
				} else if (value == 4) {
					sortStudentsOfKafedraByCourse();
				} else if (value == 5) {
					sortStudentsByKafedra();
				} else if (value == 6) {
					sortTeachersOfKafedra();
				} else if (value == 7) {
					sortStudentsOfKafedraCourse();
				}

				value = -1;

			}
		}
	}

}
