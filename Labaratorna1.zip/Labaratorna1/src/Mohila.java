
public class Mohila  {	
	public Object[] Students;
	public Object[] Teachers;
}
