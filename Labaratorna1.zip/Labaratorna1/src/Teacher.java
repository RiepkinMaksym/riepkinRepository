import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Teacher extends Kafedra {
	String Kafedra;
	String Faculty;
	String Name;
	Object[] Teachers;

	protected void addTeacher() {
		WorkingWithArrays a = new WorkingWithArrays();
		System.out.println("Input faculty to which you want to add teacher");
		String facultyName = sc.nextLine();
		if (a.lookingForFaculty(Faculties, facultyName) != null) {
			System.out.println("Input name of kafedra");
			String kafedraName = sc.nextLine();
			if (a.lookingForKafedra(Kafedras, facultyName, kafedraName) != null) {
				System.out.println("Input name of teacher");
				String teacherName = sc.nextLine();
				if (a.lookingForTeacher(Teachers, facultyName, kafedraName, teacherName) == null) {
					Object dynamicKafedra = new Teacher();
					Teachers = a.expand(Teachers, dynamicKafedra);
					Teacher t = (Teacher) Teachers[Teachers.length - 1];
					t.setFaculty(facultyName);
					t.setKafedra(kafedraName);
					t.setName(teacherName);
				} else {
					System.out.println("There are such teachers in selected kafedra");
				}
			} else {
				System.out.println("There are no such kafedras in selected faculty");
			}
		} else {
			System.out.println("There are no such faculty");
		}
	}

	protected void editTeacher() {
		WorkingWithArrays a = new WorkingWithArrays();
		System.out.println("Input faculty to which you want to edit teacher");
		String facultyName = sc.nextLine();
		if (a.lookingForFaculty(Faculties, facultyName) != null) {
			System.out.println("Input name of kafedra");
			String kafedraName = sc.nextLine();
			if (a.lookingForKafedra(Kafedras, facultyName, kafedraName) != null) {
				System.out.println("Input name of teacher");
				String teacherName = sc.nextLine();
				if (a.lookingForTeacher(Teachers, facultyName, kafedraName, teacherName) != null) {
					for (int i = 0; i < Teachers.length; i++) {
						Teacher t = (Teacher) Teachers[i];
						if (t.Name.matches(teacherName) && t.Faculty.matches(facultyName)
								&& t.Kafedra.matches(kafedraName)) {
							System.out.println("Enter new faculty name");
							facultyName = sc.nextLine();
							System.out.println("Enter new kafedra name");
							kafedraName = sc.nextLine();
							System.out.println("Enter new teacher name");
							teacherName = sc.nextLine();
							if (a.lookingForTeacher(Teachers, facultyName, kafedraName, teacherName) == null) {
								t.setFaculty(facultyName);
								t.setKafedra(kafedraName);
								t.setName(teacherName);
								System.out.println(Arrays.toString(Teachers));
								break;
							} else {
								System.out.println("Error");
							}
						}
					}
				} else {
					System.out.println("There no are such teachers in selected kafedra");
				}
			} else {
				System.out.println("There are no such kafedras in selected faculty");
			}
		} else {
			System.out.println("There are no such faculty");
		}
		System.out.println(Teachers.length);

	}

	protected void deleteTeacher() {
		WorkingWithArrays a = new WorkingWithArrays();
		System.out.println("Input faculty to which you want to edit teacher");
		String facultyName = sc.nextLine();
		if (a.lookingForFaculty(Faculties, facultyName) != null) {
			System.out.println("Input name of kafedra");
			String kafedraName = sc.nextLine();
			if (a.lookingForKafedra(Kafedras, facultyName, kafedraName) != null) {
				System.out.println("Input name of teacher");
				String teacherName = sc.nextLine();
				if (a.lookingForTeacher(Teachers, facultyName, kafedraName, teacherName) != null) {
					for (int i = 0; i < Teachers.length; i++) {
						Teacher t = (Teacher) Teachers[i];
						if (t.Faculty.matches(facultyName) && t.Kafedra.matches(kafedraName)
								&& t.Name.matches(teacherName)) {
							Teachers = a.deleteIndex(Teachers, i);
							System.out.println("Teacher " + teacherName + " deleted");
						}
					}
				} else {
					System.out.println("There no are such teachers in selected kafedra");
				}
			} else {
				System.out.println("There are no such kafedras in selected faculty");
			}
		} else {
			System.out.println("There are no such faculty");
		}
	}

	protected void sortTeachersByAlphabet() {
		if (Teachers != null) {
			WorkingWithArrays a = new WorkingWithArrays();
			String[] dynamic = new String[Teachers.length];
			int index = Teachers.length;
			for (int i = 0; i < index; i++) {
				Teacher s = (Teacher) Teachers[i];
				dynamic[i] = s.Name;
			}
			a.sortByAlphabet(index, dynamic);
		}

	}

	protected void sortTeachersOfKafedra() {
		if (Teachers != null) {
			WorkingWithArrays a = new WorkingWithArrays();
			String[] dynamic = new String[Teachers.length];
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter kafedra");
			String kafedraName = sc.nextLine();
			int index = 0;
			for (int i = 0; i < Teachers.length; i++) {
				Teacher s = (Teacher) Teachers[i];
				if (s.Kafedra.matches(kafedraName)) {
					dynamic[index] = s.Name;
					index++;
				}
			}

			a.sortByAlphabet(index, dynamic);
		}

	}

	protected void lookingForTeacherWithParams() {
		if (Teachers != null) {
			System.out.println("1 by name");
			System.out.println("2 by kafedra");
			Scanner input = new Scanner(System.in);
			int value = 0;
			try {
				value = input.nextInt();
			} catch (InputMismatchException e) {
				System.out.println("You should enter number");

				input.reset();
			}
			if (value == 1) {
				System.out.println("Enter name");
				String name = sc.nextLine();
				for (int i = 0; i < Teachers.length; i++) {
					Teacher s = (Teacher) Teachers[i];
					if (s.Name.matches(name)) {
						System.out.println("Teacher of " + s.Faculty + " " + s.Kafedra);
					}
				}
			}

			else if (value == 2) {
				System.out.println("Enter kafedra name");
				String name = sc.nextLine();
				for (int i = 0; i < Teachers.length; i++) {
					Teacher s = (Teacher) Teachers[i];
					if (s.Kafedra.matches(name)) {
						System.out.println("Student of " + s.Faculty + " " + s.Kafedra + " is on " + s.Name);
					}
				}
			}
		}
	}

	protected void sortTeachersOfFacultyByAlphabet() {
		if (Teachers != null) {
			WorkingWithArrays a = new WorkingWithArrays();
			String[] dynamic = new String[Teachers.length];
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter faculty from which you want to sort teachers");
			String facultyName = sc.nextLine();
			int index = 0;
			for (int i = 0; i < Teachers.length; i++) {
				Teacher s = (Teacher) Teachers[i];
				if (s.Faculty.matches(facultyName)) {
					dynamic[index] = s.Name;
					index++;
				}
			}

			a.sortByAlphabet(index, dynamic);
		}

	}

	public String getKafedra() {
		return Kafedra;
	}

	public void setKafedra(String kafedra) {
		Kafedra = kafedra;
	}

	public String getFaculty() {
		return Faculty;
	}

	public void setFaculty(String faculty) {
		Faculty = faculty;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}
}
