

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class StudentsCalc extends JFrame{

	private int count = 0;
	private JLabel countLabel;
	private JButton addStudent;
	private JButton removeStudent;
	
	public StudentsCalc(){
		super("ÐšÐ°Ð»ÑŒÐºÑƒÐ»Ñ�Ñ‚Ð¾Ñ€ Ñ�Ñ‚ÑƒÐ´ÐµÐ½Ñ‚Ñ–Ð²");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		countLabel = new JLabel("Ð¡Ñ‚ÑƒÐ´ÐµÐ½Ñ‚Ñ–Ð²: "+count);
		addStudent = new JButton("Ð”Ð¾Ð´Ð°Ñ‚Ð¸ Ñ�Ñ‚ÑƒÐ´ÐµÐ½Ñ‚Ð°");
		removeStudent = new JButton("ÐŸÑ€Ð¸Ð±Ñ€Ð°Ñ‚Ð¸ Ñ�Ñ‚ÑƒÐ´ÐµÐ½Ñ‚Ð°");
		
		JPanel buttonsPanel = new JPanel(new FlowLayout());
		add(countLabel, BorderLayout.NORTH);
		buttonsPanel.add(addStudent);
		buttonsPanel.add(removeStudent);
		add(buttonsPanel, BorderLayout.SOUTH);
		addStudent.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				count++;
				updateStudentsCounter();
			}


		});
		removeStudent.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if (count>0){
					count--;
					updateStudentsCounter();
				}
				
			}
		});
	}
	private void updateStudentsCounter() {
		countLabel.setText("Ð¡Ñ‚ÑƒÐ´ÐµÐ½Ñ‚Ñ–Ð²: "+count);
		
	}
	public static void main(String[] args) {
		StudentsCalc app = new StudentsCalc();
		app.setVisible(true);
		app.pack();

	}

}
