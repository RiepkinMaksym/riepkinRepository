import java.awt.Font;
import java.awt.GridLayout;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class MathGame extends JFrame {
	public static int HEIGHT = 500;
	public static int LENGTH = 500;
	JPanel askingForInfo;
	JLabel labelOnAnswerPanel;
	JPanel answerPanel;
	JLabel example;
	JTextArea answer;
	JButton okButton;
	JLabel asking;
	JPanel examplePanel;
	JTextArea askingAns;
	Font BigFontTR = new Font("TimesRoman", Font.BOLD, 30);
	boolean which;
	private int numberOfExamples;
	private int maxNumber;
	JButton firstOkButton;
	int firstNumber;
	int secondNumber;
	int rightAnswer;
	int znak;
	int when = 0;

	public MathGame() {
		super();

		this.setTitle("My Math Game");
		this.setSize(LENGTH, HEIGHT);
		// askingForInfo();
		init();
		this.add(okButton);
		okButton.addActionListener(new ButtonEventListener());
		okButton.setVisible(false);
		this.add(examplePanel);
		this.add(answerPanel);
		this.add(askingForInfo);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	class FirstButtonEventListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			if (when == 0) {
				when++;
				maxNumber = Integer.parseInt(askingAns.getText());
				if(maxNumber<=0)System.exit(0);
				asking.setText("Number of examples");
				askingAns.setText("");
			} else if (when == 1) {
				when++;
				if(numberOfExamples<=0)System.exit(0);
				numberOfExamples = Integer.parseInt(askingAns.getText());
				askingForInfo.setVisible(false);
				examplePanel.setVisible(true);
				which = true;
				generateOperation();
				okButton.setVisible(true);
			}
		}
	}

	class ButtonEventListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			if (which == true) {
				which = false;
				checkIfAnswerIsRight();
				examplePanel.setVisible(false);
				answerPanel.setVisible(true);
			} else if (which == false) {
				which = true;
				generateOperation();
				examplePanel.setVisible(true);
				answerPanel.setVisible(false);
			} else if (numberOfExamples == 0) {
				examplePanel.setVisible(false);
				answerPanel.setVisible(false);
				okButton.setVisible(false);
			}
		}
	}

	public void checkIfAnswerIsRight() {

		if (numberOfExamples == 1) {
			examplePanel.setVisible(false);
			// labelOnAnswerPanel.setText("Done");
			okButton.setVisible(false);
			// okButton.setVisible(false);
		}
		numberOfExamples--;
		String ch = answer.getText().valueOf(rightAnswer);
		if (answer.getText().matches(ch)) {
			labelOnAnswerPanel.setText("Correct!!!");
			labelOnAnswerPanel.setBounds(LENGTH / 2 - 90, HEIGHT / 2 - 100, 300, 40);
		} else {
			labelOnAnswerPanel.setText("Incorrect, " + rightAnswer + " is right");
			labelOnAnswerPanel.setBounds(LENGTH / 2 - 150, HEIGHT / 2 - 100, 300, 40);
		}
		labelOnAnswerPanel.setFont(BigFontTR);
	}

	public void generateOperation() {

		while (true) {
			firstNumber = rd.nextInt(maxNumber);
			secondNumber = rd.nextInt(maxNumber);
			znak = rd.nextInt(2);
			if (znak == 0 && firstNumber + secondNumber <= maxNumber && firstNumber + secondNumber >= 0
					&& firstNumber <= maxNumber) {
				rightAnswer = firstNumber + secondNumber;
				example.setText(firstNumber + "+" + secondNumber + "=");
				answer.setText("");
				break;
			} else if (znak == 1 && firstNumber - secondNumber <= maxNumber && firstNumber - secondNumber >= 0
					&& firstNumber <= maxNumber) {
				rightAnswer = firstNumber - secondNumber;
				example.setText(firstNumber + "-" + secondNumber + "=");
				answer.setText("");
				break;
			}

		}

	}

	public void init() {
		if (firstOkButton == null) {
			firstOkButton = new JButton("Ok");
			firstOkButton.setBounds(LENGTH - LENGTH / 2 - 50, HEIGHT - HEIGHT / 3, 50, 30);
			firstOkButton.addActionListener(new FirstButtonEventListener());
		}

		if (asking == null) {
			asking = new JLabel();
			asking.setText("Enter the highest number");
			asking.setBounds(LENGTH / 2 - 200, HEIGHT / 2 - 100, 400, 40);
			asking.setFont(BigFontTR);
		}
		if (askingAns == null) {
			askingAns = new JTextArea();
			askingAns.setBounds(LENGTH / 2 + 130, HEIGHT / 2 - 100, 40, 40);
			askingAns.setFont(BigFontTR);
		}

		if (askingForInfo == null) {
			askingForInfo = new JPanel();
			askingForInfo.setLayout(null);
			askingForInfo.setBounds(0, 0, LENGTH, HEIGHT);
			askingForInfo.add(firstOkButton);
			askingForInfo.add(askingAns);
			askingForInfo.add(asking);
			askingForInfo.setVisible(true);
		}

		if (okButton == null) {
			okButton = new JButton("Ok");
			okButton.setBounds(LENGTH - LENGTH / 2 - 50, HEIGHT - HEIGHT / 3, 50, 30);
		}
		if (example == null) {
			example = new JLabel();
			// example.setText();

			example.setFont(BigFontTR);
			example.setBounds(LENGTH - LENGTH / 2 - 100, HEIGHT - HEIGHT / 3 - 85, 100, 30);
		}
		if (answer == null) {
			answer = new JTextArea();
			answer.setFont(BigFontTR);
			answer.setBounds(LENGTH / 2 - 30, HEIGHT / 2, 70, 35);

		}
		if (labelOnAnswerPanel == null) {
			labelOnAnswerPanel = new JLabel();
			labelOnAnswerPanel.setBounds(LENGTH / 2 - 100, HEIGHT / 2 - 100, 300, 40);
		}
		if (answerPanel == null) {
			answerPanel = new JPanel();
			answerPanel.setLayout(null);
			answerPanel.setBounds(0, 0, LENGTH, HEIGHT / 2 + 50);
			answerPanel.setVisible(false);
			answerPanel.add(labelOnAnswerPanel);
			// answerPanel.add(okButton);
		}
		if (examplePanel == null) {
			examplePanel = new JPanel();
			examplePanel.setLayout(null);
			examplePanel.setBounds(0, 0, LENGTH, HEIGHT / 2 + 50);
			examplePanel.setVisible(false);
			examplePanel.add(answer);
			examplePanel.add(example);
			// examplePanel.add(okButton);
		}
	}

	public static void main(String[] args) {

		MathGame mt = new MathGame();
		mt.setVisible(true);
		// mt.askingForInfo();
	}

	Random rd = new Random();
}
