import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.security.KeyStore.Entry;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.SynchronousQueue;

public class Tester {
	File f = new File("C:\\eclipse Workspace\\HW11\\Library");
	File[] file = f.listFiles();
	Map<String, Integer> m = new HashMap<String, Integer>();
	int numberOfWords=0;
	public void readingOutOfFile() throws IOException {
		for (File ff : file) {
			BufferedReader in = new BufferedReader(new FileReader(ff.getAbsoluteFile()));
			String s;
			String word = "";
			while ((s = in.readLine()) != null) {
				for (int i = 0; i < s.length(); i++) {
					if (!Character.isLetter(s.charAt(i))) {
						Integer freq = m.get(word);
						m.put(word, freq == null ? 1 : freq + 1);
						word = "";
						numberOfWords++;
						continue;
					}
					word += s.substring(i, i + 1);
					
				}
			}
			in.close();
		}

	}

	public void creatingAndInsertingInfoInFile() {
		File newFile = new File("C:\\eclipse Workspace\\HW11\\Library\\Summary.txt");
		try {
			newFile.createNewFile();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		try {
			PrintWriter out = new PrintWriter(newFile.getAbsoluteFile());
			List list=sortMapByValue();
			for(int i=0;i<list.size();i++){
				out.println(list.get(i));
			}
			//out.println(sortMapByValue());
			int size=m.size()-1;
			out.println("Dictionary "+size);
			out.println("Total number of words "+numberOfWords);
			out.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	public List sortMapByValue(){
		 List entryList = new ArrayList(m.entrySet());
		    Collections.sort(entryList, new Comparator() {
		        public int compare(Object o1, Object o2) {
		            Map.Entry e1 = (Map.Entry) o1;
		            Map.Entry e2 = (Map.Entry) o2;
		            Comparable c1 = (Comparable) e1.getValue();
		            Comparable c2 = (Comparable) e2.getValue();
		            return c1.compareTo(c2);
		        }
		    });
		    entryList.remove(entryList.size()-1);
		    return entryList;
	}
	

	public static void main(String[] args) throws IOException {
		Tester t = new Tester();
		t.readingOutOfFile();
		t.creatingAndInsertingInfoInFile();
	}

}
